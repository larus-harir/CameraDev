import 'dart:io';
import 'package:ffmpeg_kit_flutter_new/ffmpeg_kit.dart';
import 'package:ffmpeg_kit_flutter_new/return_code.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import '../models/filter_preset.dart';

/// Export-only video filter. Approximates the Lightroom-inspired photo preset.
/// FFmpeg color filters are not pixel-identical to the photo engine.
class VideoFilterService {
  Future<String> render(String input, FilterPreset preset, double strength) async {
    if (preset.id == 'original' || strength <= 0) return input;
    final amount = strength.clamp(0.0, 1.0);
    final dir = await getTemporaryDirectory();
    final output = p.join(dir.path, 'filtered_${DateTime.now().microsecondsSinceEpoch}.mp4');
    final exposure = (preset.exposure * amount / 5).clamp(-1.0, 1.0);
    final contrast = (1 + (preset.contrast + preset.dehaze * 0.3 + preset.clarity * 0.2) * amount / 100).clamp(0.2, 2.0);
    final saturation = (1 + (preset.saturation + preset.vibrance * 0.4) * amount / 100).clamp(0.0, 3.0);
    final gamma = (1 + (preset.shadows * 0.2 - preset.highlights * 0.2) * amount / 100).clamp(0.5, 2.0);
    final red = ((preset.temperature + preset.tint * 0.35) * amount / 300).clamp(-1.0, 1.0);
    final green = (-preset.tint * amount / 300).clamp(-1.0, 1.0);
    final blue = ((-preset.temperature + preset.tint * 0.35) * amount / 300).clamp(-1.0, 1.0);
    final brightness = (exposure + (preset.whites + preset.blacks) * amount / 1200).clamp(-1.0, 1.0);
    final filters = <String>[
      'eq=brightness=$brightness:contrast=$contrast:saturation=$saturation:gamma=$gamma',
      'colorbalance=rs=$red:gs=$green:bs=$blue',
    ];
    final vignette = (-preset.vignette * amount / 100).clamp(0.0, 1.0);
    if (vignette > 0.001) filters.add('vignette=angle=${(0.15 + vignette * 0.6).toStringAsFixed(3)}');
    final grain = (preset.grain * amount * 0.4).round().clamp(0, 40);
    if (grain > 0) filters.add('noise=alls=$grain:allf=t');
    // Scale down only if the input exceeds 1080p. Preserve aspect ratio.
    filters.add('scale=w=1920:h=1080:force_original_aspect_ratio=decrease:force_divisible_by=2');
    final vf = filters.join(',');
    String quote(String value) => '"${value.replaceAll('"', '\\"')}"';
    final command = '-hide_banner -loglevel error -y -i ${quote(input)} '
        '-vf ${quote(vf)} -map 0:v:0 -map 0:a? -c:v libx264 -preset veryfast '
        '-crf 20 -pix_fmt yuv420p -c:a aac -b:a 192k -movflags +faststart ${quote(output)}';
    final session = await FFmpegKit.execute(command);
    final result = await session.getReturnCode();
    if (!ReturnCode.isSuccess(result) || !await File(output).exists()) {
      final logs = await session.getOutput();
      throw StateError('동영상 필터 처리 실패: $logs');
    }
    return output;
  }
}
