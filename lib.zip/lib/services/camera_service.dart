import 'package:camera/camera.dart';
import 'package:flutter/material.dart' show Offset;

class CameraService {
  CameraController? controller;
  List<CameraDescription> cameras = [];
  int currentCameraIndex = 0;
  double minZoom = 1.0;
  double maxZoom = 1.0;
  bool videoMode = false;
  bool microphoneEnabled = true;

  Future<void> initialize() async {
    cameras = await availableCameras();
    cameras.sort((a, b) {
      int priority(CameraDescription c) =>
          c.lensDirection == CameraLensDirection.back ? 0 :
          c.lensDirection == CameraLensDirection.front ? 1 : 2;
      return priority(a).compareTo(priority(b));
    });
    if (cameras.isEmpty) throw Exception('사용 가능한 카메라가 없습니다.');
    if (currentCameraIndex >= cameras.length) currentCameraIndex = 0;
    await _startCurrentCamera();
  }

  Future<void> _startCurrentCamera() async {
    final oldController = controller;
    controller = null;
    await oldController?.dispose();

    controller = CameraController(
      cameras[currentCameraIndex],
      videoMode ? ResolutionPreset.high : ResolutionPreset.max,
      enableAudio: videoMode && microphoneEnabled,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );
    await controller!.initialize();
    minZoom = await controller!.getMinZoomLevel();
    maxZoom = await controller!.getMaxZoomLevel();
    await setZoom(1.0.clamp(minZoom, maxZoom).toDouble());
  }

  Future<void> configureVideo({required bool enabled, required bool microphone}) async {
    if (controller?.value.isRecordingVideo ?? false) {
      throw StateError('녹화 중에는 모드를 바꿀 수 없습니다.');
    }
    if (videoMode == enabled && microphoneEnabled == microphone) return;
    videoMode = enabled;
    microphoneEnabled = microphone;
    await _startCurrentCamera();
  }

  Future<void> startVideo() async {
    final c = controller;
    if (c == null || !c.value.isInitialized || c.value.isRecordingVideo) {
      throw StateError('녹화를 시작할 수 없습니다.');
    }
    await c.startVideoRecording();
  }

  Future<XFile> stopVideo() async {
    final c = controller;
    if (c == null || !c.value.isRecordingVideo) {
      throw StateError('진행 중인 녹화가 없습니다.');
    }
    return c.stopVideoRecording();
  }

  Future<void> switchCamera() async {
    if (cameras.length < 2) return;
    final currentDirection = cameras[currentCameraIndex].lensDirection;
    final targetDirection = currentDirection == CameraLensDirection.back
        ? CameraLensDirection.front : CameraLensDirection.back;
    final index = cameras.indexWhere((c) => c.lensDirection == targetDirection);
    currentCameraIndex = index >= 0 ? index : (currentCameraIndex + 1) % cameras.length;
    await _startCurrentCamera();
  }

  Future<void> setZoom(double value) async {
    final c = controller;
    if (c == null || !c.value.isInitialized) return;
    await c.setZoomLevel(value.clamp(minZoom, maxZoom).toDouble());
  }

  Future<void> setFlash(FlashMode mode) async {
    final c = controller;
    if (c == null || !c.value.isInitialized) return;
    await c.setFlashMode(mode);
  }


  Future<bool> focusAt(double x, double y) async {
    final c = controller;
    if (c == null || !c.value.isInitialized) return false;
    bool focused = false;
    final point = Offset(x.clamp(0.0, 1.0), y.clamp(0.0, 1.0));
    try {
      await c.setFocusMode(FocusMode.auto);
      await c.setFocusPoint(point);
      focused = true;
    } catch (_) {
      // Some devices do not support custom focus points.
    }
    try {
      await c.setExposurePoint(point);
    } catch (_) {
      // Exposure point selection is optional.
    }
    return focused;
  }

  Future<XFile> takePicture() async {
    final c = controller;
    if (c == null || !c.value.isInitialized) {
      throw Exception('카메라가 준비되지 않았습니다.');
    }
    return c.takePicture();
  }

  Future<void> dispose() async {
    final old = controller;
    controller = null;
    await old?.dispose();
  }
}
