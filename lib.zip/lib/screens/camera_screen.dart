import 'dart:async';
import 'dart:io';
import 'dart:typed_data';
import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import '../models/camera_settings.dart';
import '../models/filter_preset.dart';
import '../services/filter_service.dart';
import '../services/video_filter_service.dart';
import '../widgets/filter_selector.dart';
import '../services/camera_service.dart';
import '../services/photo_storage_service.dart';
import '../services/settings_service.dart';
import '../widgets/grid_overlay.dart';
import 'gallery_screen.dart';
import 'settings_screen.dart';

class CameraScreen extends StatefulWidget {
  const CameraScreen({super.key});
  @override
  State<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends State<CameraScreen> with WidgetsBindingObserver {
  final _camera = CameraService();
  final _settingsService = SettingsService();
  final _storage = PhotoStorageService();
  final _filterService = FilterService();
  final _videoFilterService = VideoFilterService();
  Uint8List? _capturedOriginal;
  String _capturedRatio = '4:3';
  bool _capturedDualSave = false;
  String _recordFilterId = 'original';
  double _recordFilterStrength = 1;
  bool _recordDualSave = false;
  String _filterId = 'original';
  double _filterStrength = 1.0;
  bool _filterPanelVisible = false;
  CameraSettings _settings = const CameraSettings();
  bool _ready = false;
  bool _videoMode = false;
  bool _recording = false;
  bool _recordingBusy = false;
  bool _microphone = true;
  DateTime? _recordingStarted;
  Timer? _recordingTicker;
  Duration _recordedDuration = Duration.zero;
  bool _busy = false;
  bool _showPreview = false;
  Uint8List? _captured;
  double _zoom = 1, _minZoom = 1, _maxZoom = 1;
  bool _zoomSliderVisible = false;
  bool _timerCancelled = false;
  FlashMode _flash = FlashMode.off;
  int _timer = 0, _countdown = 0;
  String _ratio = '4:3';
  Offset? _focusPoint;
  int _focusToken = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      _settings = await _settingsService.load();
      final savedFilter = await _settingsService.loadFilter();
      _filterId = CameraFilters.byId(savedFilter.$1).id;
      _filterStrength = savedFilter.$2;
      await _camera.initialize();
      _minZoom = _camera.minZoom;
      _maxZoom = _camera.maxZoom;
      _zoom = 1.0.clamp(_minZoom, _maxZoom).toDouble();
      _zoomSliderVisible = false;
      if (mounted) setState(() => _ready = true);
    } catch (e) {
      _message('카메라 초기화 실패: $e');
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.inactive || state == AppLifecycleState.paused) {
      _timerCancelled = true;
      if (_recording) {
        // Stop and publish the recording before disposing the camera.
        _stopRecording();
        return;
      }
      _camera.dispose();
      if (mounted) setState(() => _ready = false);
    } else if (state == AppLifecycleState.resumed && !_ready) {
      _initialize();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _recordingTicker?.cancel();
    _camera.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _openSettings() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => SettingsScreen(
      initialSettings: _settings,
      onSave: (value) async {
        _settings = value;
        await _settingsService.save(value);
        if (mounted) setState(() {});
      },
    )));
    if (mounted) setState(() {});
  }

  Future<void> _switchCamera() async {
    if (_busy || !_ready || _recording || _recordingBusy) return;
    _timerCancelled = true;
    setState(() => _ready = false);
    try {
      await _camera.switchCamera();
      _minZoom = _camera.minZoom;
      _maxZoom = _camera.maxZoom;
      _zoom = 1.0.clamp(_minZoom, _maxZoom).toDouble();
      _zoomSliderVisible = false;
      _flash = FlashMode.off;
    } catch (e) {
      _message('카메라 전환 실패: $e');
    } finally {
      if (mounted) setState(() => _ready = _camera.controller?.value.isInitialized ?? false);
    }
  }

  Future<void> _cycleFlash() async {
    const modes = [FlashMode.off, FlashMode.auto, FlashMode.always, FlashMode.torch];
    final next = modes[(modes.indexOf(_flash) + 1) % modes.length];
    try {
      await _camera.setFlash(next);
      if (mounted) setState(() => _flash = next);
    } catch (_) {
      _message('이 카메라는 해당 플래시 모드를 지원하지 않습니다.');
    }
  }

  int _pendingSaves = 0;

  Future<void> _capture() async {
    if (_busy || !_ready || _videoMode || _recordingBusy) return;
    if (_pendingSaves >= 3 && !_settings.showCapturePreview && !_settings.askBeforeSaving) {
      _message('저장 작업이 밀려 있어요. 잠시 후 촬영해 주세요.');
      return;
    }
    _timerCancelled = false;
    setState(() { _busy = true; _countdown = _timer; _zoomSliderVisible = false; });
    try {
      for (int remaining = _timer; remaining > 0; remaining--) {
        await Future.delayed(const Duration(seconds: 1));
        if (!mounted || !_ready || _timerCancelled) return;
        setState(() => _countdown = remaining - 1);
      }
      // Snapshot all settings BEFORE allowing another capture.
      final ratio = _ratio;
      final preset = CameraFilters.byId(_filterId);
      final strength = _filterStrength;
      final showPreview = _settings.showCapturePreview;
      final ask = _settings.askBeforeSaving;
      final dualSave = _settings.saveOriginalAlongsideFilter && preset.id != 'original' && strength > 0;
      final photo = await _camera.takePicture();
      // Auto-save: camera is usable again immediately after capture.
      // JPEG processing and gallery I/O continue asynchronously.
      if (!showPreview && !ask) {
        _pendingSaves++;
        _processAndSave(photo.readAsBytes(), ratio, preset, strength, dualSave);
        _message('촬영 완료 · 저장 처리 중 ($_pendingSaves)');
        return;
      }
      final rawBytes = await photo.readAsBytes();
      final bytes = await _filterService.processCapture(rawBytes, ratio, preset, strength);
      _capturedOriginal = dualSave ? rawBytes : null;
      _capturedRatio = ratio;
      _capturedDualSave = dualSave;
      if (!mounted) return;
      if (showPreview) {
        setState(() { _captured = bytes; _showPreview = true; });
      } else {
        final save = await showDialog<bool>(
          context: context,
          barrierDismissible: false,
          builder: (ctx) => AlertDialog(
            title: const Text('사진 저장'),
            content: const Text('촬영한 사진을 갤러리에 저장할까요?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('취소')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('저장')),
            ],
          ),
        );
        if (save == true) await _save(bytes);
      }
    } catch (e) {
      _message('촬영 실패: $e');
    } finally {
      if (mounted) setState(() { _busy = false; _countdown = 0; });
    }
  }

  Future<void> _processAndSave(Future<Uint8List> readBytes,
      String ratio, FilterPreset preset, double strength, bool dualSave) async {
    try {
      final original = await readBytes;
      final bytes = await _filterService.processCapture(original, ratio, preset, strength);
      await _savePair(bytes, dualSave ? original : null, ratio, preset.id);
      _message('갤러리에 저장했어요.');
    } catch (e) {
      _message('사진 저장 실패: $e');
    } finally {
      _pendingSaves--;
    }
  }

  Future<void> _save(Uint8List bytes) async {
    try {
      await _savePair(bytes, _capturedDualSave ? _capturedOriginal : null, _capturedRatio, _filterId);
      if (mounted) setState(() { _showPreview = false; _captured = null; _capturedOriginal = null; });
      _message('갤러리에 저장했어요.');
    } catch (e) {
      _message('사진 저장 실패: $e');
    }
  }

  Future<void> _savePair(Uint8List filtered, Uint8List? original,
      String ratio, String filterId) async {
    final stamp = DateTime.now().microsecondsSinceEpoch;
    final base = 'IMG_$stamp';
    await _storage.saveToGallery(filtered, name: '${base}_${filterId.toUpperCase()}.jpg');
    if (original != null) {
      // Match the selected aspect ratio, but do not apply the color filter.
      final originalPreset = CameraFilters.byId('original');
      final cropped = await _filterService.processCapture(original, ratio, originalPreset, 0);
      await _storage.saveToGallery(cropped, name: '${base}_ORIGINAL.jpg');
    }
  }

  Future<void> _tapToFocus(TapDownDetails details, Size viewSize) async {
    if (_busy || !_ready || viewSize.width == 0 || viewSize.height == 0) return;
    final local = details.localPosition;
    final x = (local.dx / viewSize.width).clamp(0.0, 1.0);
    final y = (local.dy / viewSize.height).clamp(0.0, 1.0);
    final token = ++_focusToken;
    setState(() => _focusPoint = Offset(local.dx, local.dy));
    try {
      final result = await _camera.focusAt(x, y);
      if (!result) _message('이 렌즈에서는 터치 초점 위치를 지원하지 않을 수 있습니다.');
    } catch (e) {
      _message('초점 설정 실패: $e');
    }
    await Future.delayed(const Duration(milliseconds: 900));
    if (mounted && token == _focusToken) setState(() => _focusPoint = null);
  }

  Widget _viewfinder(CameraController controller) {
    return LayoutBuilder(builder: (context, constraints) {
      final portrait = constraints.maxHeight >= constraints.maxWidth;
      final landscapeRatio = _ratio == '1:1' ? 1.0 : _ratio == '16:9' ? 16 / 9 : 4 / 3;
      final targetRatio = portrait ? 1 / landscapeRatio : landscapeRatio;
      final available = Size(constraints.maxWidth, constraints.maxHeight);
      final frameWidth = available.width < available.height * targetRatio
          ? available.width : available.height * targetRatio;
      final frameHeight = frameWidth / targetRatio;
      final cameraRatio = portrait ? 1 / controller.value.aspectRatio : controller.value.aspectRatio;
      return Center(child: SizedBox(
        width: frameWidth,
        height: frameHeight,
        child: ClipRect(child: Stack(fit: StackFit.expand, children: [
          ColorFiltered(
            // Preview filter is disabled in video mode: MP4 is recorded unfiltered.
            colorFilter: CameraFilters.colorFilter(
              CameraFilters.byId(_videoMode ? 'original' : _filterId),
              _videoMode ? 0 : _filterStrength),
            child: FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: cameraRatio * 1000,
                height: 1000,
                child: CameraPreview(controller),
              ),
            ),
          ),
          if (_settings.showGrid) const IgnorePointer(child: GridOverlay()),
          LayoutBuilder(builder: (context, box) => GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTapDown: (details) => _tapToFocus(details, Size(box.maxWidth, box.maxHeight)),
            child: Stack(children: [
              if (_focusPoint != null)
                Positioned(
                  left: (_focusPoint!.dx - 26).clamp(0, box.maxWidth - 52),
                  top: (_focusPoint!.dy - 26).clamp(0, box.maxHeight - 52),
                  child: const IgnorePointer(child: SizedBox(
                    width: 52, height: 52,
                    child: DecoratedBox(decoration: BoxDecoration(
                      border: Border.fromBorderSide(BorderSide(color: Colors.amber, width: 2)),
                    )),
                  )),
          )]),
          )),
        ])),
      ));
    });
  }

  Widget _control(IconData icon, String label, VoidCallback onTap) => InkWell(
    onTap: onTap,
    borderRadius: BorderRadius.circular(14),
    child: Padding(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 4),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Icon(icon, color: Colors.white, size: 23),
        const SizedBox(height: 3),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 11)),
      ]),
    ),
  );

  Future<void> _setVideoMode(bool enabled) async {
    if (_recording || _recordingBusy || _busy || !_ready || _videoMode == enabled) return;
    setState(() { _ready = false; _filterPanelVisible = false; });
    try {
      await _camera.configureVideo(enabled: enabled, microphone: _microphone);
      _minZoom = _camera.minZoom;
      _maxZoom = _camera.maxZoom;
      _zoom = 1.0.clamp(_minZoom, _maxZoom).toDouble();
      _flash = FlashMode.off;
      if (mounted) setState(() => _videoMode = enabled);
    } catch (e) {
      _message('촬영 모드 변경 실패: $e');
    } finally {
      if (mounted) setState(() => _ready = _camera.controller?.value.isInitialized ?? false);
    }
  }

  Future<void> _toggleMicrophone() async {
    if (!_videoMode || _recording || _recordingBusy) return;
    final next = !_microphone;
    setState(() => _ready = false);
    try {
      await _camera.configureVideo(enabled: true, microphone: next);
      if (mounted) setState(() => _microphone = next);
    } catch (e) {
      _message('마이크 설정 실패: $e');
    } finally {
      if (mounted) setState(() => _ready = _camera.controller?.value.isInitialized ?? false);
    }
  }

  Future<void> _startRecording() async {
    if (!_videoMode || !_ready || _recording || _recordingBusy) return;
    setState(() => _recordingBusy = true);
    try {
      _recordFilterId = _filterId;
      _recordFilterStrength = _filterStrength;
      _recordDualSave = _settings.saveOriginalAlongsideFilter;
      await _camera.startVideo();
      _recordingStarted = DateTime.now();
      _recordedDuration = Duration.zero;
      _recordingTicker?.cancel();
      _recordingTicker = Timer.periodic(const Duration(milliseconds: 250), (_) {
        if (mounted && _recordingStarted != null) {
          setState(() => _recordedDuration = DateTime.now().difference(_recordingStarted!));
        }
      });
      if (mounted) setState(() => _recording = true);
    } catch (e) {
      _message('동영상 녹화 시작 실패: $e');
    } finally {
      if (mounted) setState(() => _recordingBusy = false);
    }
  }

  Future<void> _stopRecording() async {
    if (!_recording || _recordingBusy) return;
    _recordingTicker?.cancel();
    setState(() => _recordingBusy = true);
    try {
      final video = await _camera.stopVideo();
      if (mounted) setState(() => _recording = false);
      _message('녹화 완료 · 갤러리에 저장 중');
      // Publish asynchronously so the camera can be used again.
      unawaited(_publishVideo(video.path, _recordFilterId, _recordFilterStrength, _recordDualSave));
      if (WidgetsBinding.instance.lifecycleState != AppLifecycleState.resumed) {
        await _camera.dispose();
        if (mounted) setState(() => _ready = false);
      }
    } catch (e) {
      _message('동영상 녹화 종료 실패: $e');
    } finally {
      _recordingStarted = null;
      if (mounted) setState(() => _recordingBusy = false);
    }
  }

  Future<void> _publishVideo(String path, String filterId,
      double strength, bool dualSave) async {
    String? processed;
    try {
      final preset = CameraFilters.byId(filterId);
      final filtered = preset.id != 'original' && strength > 0;
      final stamp = DateTime.now().microsecondsSinceEpoch;
      final base = 'VID_$stamp';
      if (filtered) {
        _message('동영상 필터 인코딩 중 · 잠시 기다려 주세요.');
        processed = await _videoFilterService.render(path, preset, strength);
        await _storage.saveVideoToGallery(processed,
            name: '${base}_${filterId.toUpperCase()}.mp4');
        if (dualSave) {
          await _storage.saveVideoToGallery(path, name: '${base}_ORIGINAL.mp4');
        }
      } else {
        await _storage.saveVideoToGallery(path, name: '${base}_ORIGINAL.mp4');
      }
      _message('동영상 저장 완료');
    } catch (e) {
      // Never silently publish an unfiltered clip as if the filter worked.
      _message('동영상 처리 실패: $e (원본 임시 파일 확인 필요)');
    } finally {
      if (processed != null && processed != path) {
        try { await File(processed).delete(); } catch (_) {}
      }
      // Keep source file on error for recovery. Camera plugin owns its location.
    }
  }

  String get _recordingTime {
    final minutes = _recordedDuration.inMinutes.remainder(60).toString().padLeft(2, '0');
    final seconds = _recordedDuration.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  Widget _shutter() => GestureDetector(
    onTap: _videoMode ? (_recording ? _stopRecording : _startRecording) : _capture,
    child: Container(
      width: 72, height: 72,
      decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: Colors.white, width: 4)),
      child: Center(child: Container(
        width: 54, height: 54,
        decoration: BoxDecoration(shape: BoxShape.circle, color: _recording ? Colors.red : (_videoMode ? Colors.redAccent : (_busy || _recordingBusy ? Colors.white38 : Colors.white))),
      )),
    ),
  );

  Future<void> _setZoom(double value) async {
    final target = value.clamp(_minZoom, _maxZoom).toDouble();
    if (mounted) setState(() => _zoom = target);
    try {
      await _camera.setZoom(target);
    } catch (e) {
      _message('줌 설정 실패: $e');
    }
  }

  Widget _zoomSelector() {
    final stops = <double>[];
    for (final v in [_minZoom, 0.6, 1.0, 2.0, 3.0, 5.0, _maxZoom]) {
      if (v >= _minZoom && v <= _maxZoom &&
          !stops.any((s) => (s - v).abs() < 0.05)) stops.add(v);
    }
    stops.sort();
    return Column(mainAxisSize: MainAxisSize.min, children: [
      SizedBox(height: 43, child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(mainAxisSize: MainAxisSize.min, children: stops.map((value) {
          final selected = (_zoom - value).abs() < 0.06;
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: ActionChip(
              label: Text('${value.toStringAsFixed( value == value.roundToDouble() ? 0 : 1)}x'),
              backgroundColor: selected ? const Color(0xFFD8B88A) : Colors.black54,
              labelStyle: TextStyle(color: selected ? Colors.black : Colors.white),
              onPressed: () {
                if (selected) {
                  setState(() => _zoomSliderVisible = !_zoomSliderVisible);
                } else {
                  setState(() => _zoomSliderVisible = true);
                  _setZoom(value);
                }
              },
            ),
          );
        }).toList()),
      )),
      if (_zoomSliderVisible)
        Row(children: [
          IconButton(
            onPressed: () => setState(() => _zoomSliderVisible = false),
            icon: const Icon(Icons.close, color: Colors.white, size: 18),
            tooltip: '줌 슬라이더 닫기',
          ),
          Expanded(child: Slider(
            min: _minZoom,
            max: _maxZoom > _minZoom ? _maxZoom : _minZoom + 0.001,
            value: _zoom.clamp(_minZoom, _maxZoom > _minZoom ? _maxZoom : _minZoom + 0.001).toDouble(),
            onChanged: _maxZoom > _minZoom ? (v) => _setZoom(v) : null,
          )),
          SizedBox(width: 54, child: Text('${_zoom.toStringAsFixed(1)}x',
            style: const TextStyle(color: Colors.white))),
        ]),
    ]);
  }

  void _updateFilter(String id, double strength) {
    setState(() { _filterId = id; _filterStrength = strength; });
    _settingsService.saveFilter(id, strength);
  }

  Widget _filterPanel() => FilterSelector(
    selectedId: _filterId,
    strength: _filterStrength,
    onSelected: (id) => _updateFilter(id, _filterStrength),
    onStrengthChanged: (v) => _updateFilter(_filterId, v),
  );

  Widget _controls(bool landscape) {
    final timer = _control(Icons.timer_outlined, _timer == 0 ? '타이머 OFF' : '$_timer초', () {
      const values = [0, 3, 5, 10];
      setState(() => _timer = values[(values.indexOf(_timer) + 1) % values.length]);
    });
    final ratio = _control(Icons.aspect_ratio, _ratio, () {
      const values = ['4:3', '16:9', '1:1'];
      setState(() => _ratio = values[(values.indexOf(_ratio) + 1) % values.length]);
    });
    final flip = _control(Icons.cameraswitch_outlined, '전환', _switchCamera);
    final grid = _control(_settings.showGrid ? Icons.grid_on : Icons.grid_off, '그리드', () async {
      final next = _settings.copyWith(showGrid: !_settings.showGrid);
      setState(() => _settings = next);
      await _settingsService.save(next);
    });
    final flash = _control(_flash == FlashMode.off ? Icons.flash_off : Icons.flash_on, '플래시', _cycleFlash);
    final gallery = _control(Icons.photo_library_outlined, '갤러리', () => Navigator.push(context,
      MaterialPageRoute(builder: (_) => const GalleryScreen())));
    final settings = _control(Icons.settings_outlined, '설정', _openSettings);
    final filters = _control(Icons.auto_fix_high, _filterPanelVisible ? '필터 닫기' : '필터',
      () => setState(() => _filterPanelVisible = !_filterPanelVisible));
    if (landscape) {
      return Container(color: Colors.black87, width: 180, child: SingleChildScrollView(child: Column(children: [
        const SizedBox(height: 8), gallery, settings,
        _control(Icons.photo_camera, '사진', () => _setVideoMode(false)),
        _control(Icons.videocam, '동영상', () => _setVideoMode(true)),
        filters, flash,
        if (!_videoMode) timer, if (!_videoMode) ratio,
        if (_videoMode) _control(_microphone ? Icons.mic : Icons.mic_off,
          '마이크', _toggleMicrophone),
        if (_filterPanelVisible && !_recording) SizedBox(width: 180, child: _filterPanel()),
        const SizedBox(height: 8), _zoomSelector(), const SizedBox(height: 12),
        _shutter(), if (_recording) Text(_recordingTime, style: const TextStyle(color: Colors.redAccent)),
        const SizedBox(height: 8), flip, grid,
      ])));
    }
    return Container(color: Colors.black87, padding: const EdgeInsets.fromLTRB(8, 8, 8, 12),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [gallery, flash,
          if (!_videoMode) timer, if (!_videoMode) ratio,
          if (!_recording) filters,
          if (_videoMode) _control(_microphone ? Icons.mic : Icons.mic_off,
              _microphone ? '마이크' : '무음', _toggleMicrophone), settings]),
        _zoomSelector(),
        if (_filterPanelVisible) _filterPanel(),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          TextButton(onPressed: _recording ? null : () => _setVideoMode(false),
            child: Text('사진', style: TextStyle(color: !_videoMode ? Colors.amber : Colors.white70))),
          const SizedBox(width: 18), _shutter(), const SizedBox(width: 18),
          TextButton(onPressed: _recording ? null : () => _setVideoMode(true),
            child: Text('동영상', style: TextStyle(color: _videoMode ? Colors.amber : Colors.white70))),
          _control(Icons.cameraswitch_outlined, '전환', _switchCamera),
        ]),
      ]));
  }

  @override
  Widget build(BuildContext context) {
    final controller = _camera.controller;
    if (!_ready || controller == null || !controller.value.isInitialized) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_showPreview && _captured != null) {
      return Scaffold(body: SafeArea(child: Stack(fit: StackFit.expand, children: [
        Image.memory(_captured!, fit: BoxFit.contain),
        Positioned(top: 8, left: 8, child: IconButton(
          onPressed: () => setState(() { _showPreview = false; _captured = null; }),
          icon: const Icon(Icons.close),
        )),
        Positioned(bottom: 16, left: 20, right: 20, child: Row(children: [
          Expanded(child: OutlinedButton(onPressed: () => setState(() {
            _showPreview = false; _captured = null;
          }), child: const Text('다시 촬영'))),
          const SizedBox(width: 12),
          Expanded(child: FilledButton(onPressed: () => _save(_captured!), child: const Text('저장'))),
        ])),
      ])));
    }
    return Scaffold(body: SafeArea(child: LayoutBuilder(builder: (context, constraints) {
      final landscape = constraints.maxWidth > constraints.maxHeight;
      final viewfinder = Expanded(child: Stack(fit: StackFit.expand, children: [
        _viewfinder(controller),
        if (_recording) Positioned(top: 12, left: 12, child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
          color: Colors.black54,
          child: Text('● REC  $_recordingTime', style: const TextStyle(
            color: Colors.redAccent, fontWeight: FontWeight.bold)),
        )),
        if (_countdown > 0) Center(child: IgnorePointer(child: Text('$_countdown',
          style: const TextStyle(fontSize: 110, fontWeight: FontWeight.bold,
            shadows: [Shadow(blurRadius: 8, color: Colors.black)])))),
      ]));
      return landscape
          ? Row(children: [viewfinder, _controls(true)])
          : Column(children: [viewfinder, _controls(false)]);
    })));
  }
}

